<?php

	get_header();

	if(have_posts()):while(have_posts()):the_post();
	$post_cats = wp_get_post_categories(get_the_ID(), NULL);
	sort($post_cats, SORT_NUMERIC);
?>
<div class="single">
	<div class="breadcrumb"><?php if(function_exists('bcn_display')){ bcn_display(); } ?></div>

	<div class="theSingle">
		<div class="tempContent">
			<h1 class="tc-titulo"><?php the_title(); ?></h1>
			<div class="tc-sinopse"><?php the_content(); ?></div>
		</div>
	</div>
</div>

<?php endwhile; else : endif; wp_reset_query(); ?>

<?php
	get_footer();
?>