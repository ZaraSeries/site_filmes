<div class="theSingle">
	<div class="singleLeft">
		<h1 class="sl-titulo"><?php the_title(); ?> (<?php echo get_post_meta($post->ID, 'ano-lancamento', true); ?>)</h1>

		<div class="theSinopse"><p><b>Sinopse: </b><?php echo strip_tags(get_the_content()); ?></p></div>

		<ul class="sl-infos">
			<li>Tempo de vídeo<br /><span><?php echo get_post_meta($post->ID, 'tempo', true); ?> Minutos</span></li>
			<li>Status<br /><span><?php echo get_post_meta($post->ID, 'status', true); ?></span></li>
			<li>Avaliação<br /><span><?php echo get_post_meta($post->ID, 'avaliacao', true); ?></span></li>
			<li>Classificação<br /><span><?php
			$classind = get_post_meta($post->ID, 'classind', true);
			if($classind == 10){ ?>
			<img src="<?php bloginfo('template_url'); ?>/imagens/classind10.png" alt="Classificação 10" />
			<?php }
			if($classind == 12){ ?>
			<img src="<?php bloginfo('template_url'); ?>/imagens/classind12.png" alt="Classificação 12" />
			<?php }
			if($classind == 14){ ?>
			<img src="<?php bloginfo('template_url'); ?>/imagens/classind14.png" alt="Classificação 14" />
			<?php }
			if($classind == 16){ ?>
			<img src="<?php bloginfo('template_url'); ?>/imagens/classind16.png" alt="Classificação 16" />
			<?php }
			if($classind == 18){ ?>
			<img src="<?php bloginfo('template_url'); ?>/imagens/classind18.png" alt="Classificação 18" />
			<?php } ?></span></li>
		</ul>

		<?php if(get_post_meta($post->ID, 'baixar1-nome', true) != ''){ ?>
		<div class="sl-download">
			<div class="ap-select">
				<div class="fSelect">
					<p><b>Clique para Download</b><br /><span>Clique na seta e escolha uma opção para baixar!</span></p>
				</div>

				<ul class="fOpcoes">
<?php
			$n3=1;
			while($status3!='off'){
			$baixar_nome[$n3] = get_post_meta($post->ID, 'baixar'.$n3.'-nome', true);
			if($baixar_nome[$n3]){ ?>
					<li><a href="<?php echo get_post_meta($post->ID, 'baixar'.$n3.'-link', true); ?>" target="_blank"><?php echo $baixar_nome[$n3]; ?></a></li>
<?php
			$n3++;
			}else{$status3='off';}} ?>
				</ul>
			</div>
		</div>
		<?php } ?>

		<div class="sl-genero">
			<div class="sl-titulo">Gênero</div>

			<ul class="theCategory">
<?php
				$categories = get_the_category();
				$separator = ' ';
				$output = '';
				if($categories){
					foreach($categories as $category) {
						$output .= '<li><a href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts in %s" ), $category->name ) ) . '">'.$category->cat_name.'</a><span class="icon"></span></li>'.$separator;
					}
				echo trim($output, $separator);
				}
?>
			</ul>
		</div>
	</div>

	<div class="singleRight">
		<div class="sr-trailer">
			<div class="sr-titulo">Trailer do Filme</div>
			<div class="theTrailer"><?php echo get_post_meta($post->ID, 'trailer', true); ?></div>
		</div>

		<?php if(function_exists('ReportPageErrors')){ echo ReportPageErrors(); } ?>
	</div>

	<div class="player">
			<ul class="itens">
			<li class="video0">Assistir Filmes</li>
<?php
			$n=1;
			while($status!=off){
			$video_txt[$n] = get_post_meta($post->ID, 'video'.$n.'-nome', true);
			if($video_txt[$n]){ ?>
				<li class="<?php echo "video".$n; ?>"><div class="icon"><div class="symbol"></div></div><?php echo $video_txt[$n]; ?></li>
			<?php $n++; } else {$status=off;}} ?>
			</ul>

			<ul class="videos">
<?php
			$n2=1;
			while($status2!='off'){
			$video_code[$n2] = get_post_meta($post->ID, 'video'.$n2.'-code', true);
			if($video_code[$n2]){ ?>
				<li class="<?php echo "video".$n2."-code"; ?>">
				<?php echo $video_code[$n2]; ?>
				</li>
<?php
			$n2++;
			} else {$status2='off';}} ?>
			</ul>
	</div>

	<ul class="playerOpcoes">
		<li><a href="javascript:void(window.open('https://twitter.com/share?original_referer=<?php the_permalink(); ?>&related=&source=tweetbutton&text=<?php the_title(); ?>&url=<?php the_permalink(); ?>&via=CineFilmesOnlin','_blank','width=500px,height=280px,left=0,top=0,resizable=yes,menubar=no,location=no,status=yes,scrollbars=yes'));"><img src="<?php bloginfo('template_url'); ?>/imagens/player-item_twitter.jpg" title="Twitter" /></a></li>
		<li><a href="javascript:void(window.open('http://www.facebook.com/plugins/like.php?href=<?php the_permalink(); ?>&layout=button_count&show_faces=false&width=80&action=like&colorscheme=light','_blank','width=,height=,left=0,top=0,resizable=yes,menubar=no,location=no,status=yes,scrollbars=yes'));"><img src="<?php bloginfo('template_url'); ?>/imagens/player-item_facebook.jpg" title="Facebook" /></a></li>
		<li><a href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><img src="<?php bloginfo('template_url'); ?>/imagens/player-item_googleplus.jpg" title="Google+" /></a></li>
		<li class="bso-comentarios"><img src="<?php bloginfo('template_url'); ?>/imagens/player-item_comente.jpg" title="Comente" /></li>
		<li class="apagar-luz"><img src="<?php bloginfo('template_url'); ?>/imagens/player-item_apagar.jpg" title="Apagar" /></li>
		<li class="acender-luz"><img src="<?php bloginfo('template_url'); ?>/imagens/player-item_apagar.jpg" title="Acender" /></li>
	</ul>

	<div class="blocosSingle">
		<ul class="bs-opcoes">
			<li class="bso-comentarios"><img src="<?php bloginfo('template_url'); ?>/imagens/icon-comentarios.jpg" alt="Deixe seu comentário"/><span>Deixe seu comentário</span></li>
			<li class="bso-postrelated"><img src="<?php bloginfo('template_url'); ?>/imagens/icon-postsRelacionados.jpg" alt="Postagens relacionadas"/><span>Postagens Relacionadas</span></li>
			<li><img src="<?php bloginfo('template_url'); ?>/imagens/icon-visualizacoes.jpg" alt="Visualizações"/><?php if($the_views and $the_views >= 0){ echo $the_views; } else { echo '0'; } ?><span> Visualizações</span></li>
		</ul>
		<div class="bs-seta" style="margin-left: 423px;"></div>

		<ul class="bs-content">
			<li class="bs-comentarios">
				<div class="fb-comments" data-href="<?php the_permalink() ?>" data-width="885" data-numposts="5" data-colorscheme="dark"></div>
			</li>
			
			<li class="bs-postrelated"><?php include('postRelated.php'); ?></li>
		</ul>
	</div>
</div>