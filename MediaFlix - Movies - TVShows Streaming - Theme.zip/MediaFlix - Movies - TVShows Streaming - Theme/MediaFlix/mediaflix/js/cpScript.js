$(function(){

	// Campos p/ Filmes
	var tmItem  = '<li><input type="text" name="video-nome" id="video-nome" size="30" style="width:97%" placeholder="Nome do Player" />' +
				  '<textarea name="video-code" id="video-code" cols="60" rows="4" style="width:97%" placeholder="Código do Player"></textarea>' +
				  '<div class="cp-tmRemove"><a class="button btn-tmRemove">-</a><p>Remover os dois campos acima.</p></div></li>';

	function tmItem_update(){
		var nitens = 1;
		var itemName = '';
		var itemName2 = '';
		var ulitens = $(".cpFilmes ul li");
		for (var i = 1; i <= ulitens.length; i++) {
			itemName = 'video'+i+'-nome';
			itemName2 = 'video'+i+'-code';
			$('.cpFilmes ul li:nth-child('+i+') input').attr("name", itemName);
			$('.cpFilmes ul li:nth-child('+i+') input').attr("id", itemName);
			$('.cpFilmes ul li:nth-child('+i+') textarea').attr("name", itemName2);
			$('.cpFilmes ul li:nth-child('+i+') textarea').attr("id", itemName2);
		}

	}

	$('.cpFilmes a.btn-tmAdd').click(function(){
		if($('.cpFilmes ul li').length == 0){
			$('.cpFilmes ul').html(tmItem);
		} else {
			$('.cpFilmes ul li:last-child').after(tmItem);
		}
		$('.cpFilmes .cp-tmRemove').css('display','block');
		tmItem_update();
	});

	$('.cpFilmes').delegate('.btn-tmRemove', 'click', function(){
		$(this).parent().parent().remove();
		tmItem_update();
	});

	// Campos p/ Baixar
	var tmItem2 = '<li><input type="text" name="baixar-nome" id="baixar-nome" class="baixar-nome" size="30" style="width:97%" placeholder="Nome do servidor" />' +
				  '<input type="text" name="baixar-link" id="baixar-link" class="baixar-link" size="30" style="width:97%" placeholder="Link do servidor" />' +
				  '<div class="cp-tmRemove"><a class="button btn-tmRemove">-</a><p>Remover os dois campos acima.</p></div></li>';

	function tmItem2_update(){
		var nitens2 = 1;
		var itemName3 = '';
		var itemName4 = '';
		var ulitens2 = $(".cpBaixar ul li");
		for (var i2 = 1; i2 <= ulitens2.length; i2++) {
			itemName3 = 'baixar'+i2+'-nome';
			itemName4 = 'baixar'+i2+'-link';
			$('.cpBaixar ul li:nth-child('+i2+') input.baixar-nome').attr("name", itemName3);
			$('.cpBaixar ul li:nth-child('+i2+') input.baixar-nome').attr("id", itemName3);
			$('.cpBaixar ul li:nth-child('+i2+') input.baixar-link').attr("name", itemName4);
			$('.cpBaixar ul li:nth-child('+i2+') input.baixar-link').attr("id", itemName4);
		}

	}

	$('.cpBaixar a.btn-tmAdd').click(function(){
		if($('.cpBaixar ul li').length == 0){
			$('.cpBaixar ul').html(tmItem2);
		} else {
			$('.cpBaixar ul li:last-child').after(tmItem2);
		}
		$('.cpBaixar .cp-tmRemove').css('display','block');
		tmItem2_update();

	});

	$('.cpBaixar').delegate('.btn-tmRemove', 'click', function(){
		$(this).parent().parent().remove();
		tmItem2_update();

	});

	// Campos p/ Temporadas
	var tmItem3 = '<li><input type="text" name="temporadas-codigo" id="temporadas-codigo" class="temporadas-codigo" size="30" style="width:97%" placeholder="Código do Episódio" />' +
				  '<input type="text" name="temporadas-titulo" id="temporadas-titulo" class="temporadas-titulo" size="30" style="width:97%" placeholder="Nome do Episódio" />' +
				  '<input type="text" name="temporadas-link" id="temporadas-link" class="temporadas-link" size="30" style="width:97%" placeholder="Link do Episódio" />' +
				  '<div class="cp-tmRemove"><a class="button btn-tmRemove">-</a><p>Remover os dois campos acima.</p></div></li>';

	function tmItem3_update(){
		var nitens3 = 1;
		var itemName5 = '';
		var itemName6 = '';
		var ulitens3 = $(".cpTemporadas ul li");
		for (var i3 = 1; i3 <= ulitens3.length; i3++) {
			itemCod = $('.cpTemporadas ul li:nth-child('+i3+') input.temporadas-codigo').val();
			if(itemCod == "undefined" || itemCod == ""){
				itemCod = "temporadas";
			}
			itemName5 = itemCod+'-codigo';
			itemName6 = itemCod+'-titulo';
			itemName7 = itemCod+'-link';
			
			$('.cpTemporadas ul li:nth-child('+i3+') input.temporadas-codigo').attr("name", itemName5);
			$('.cpTemporadas ul li:nth-child('+i3+') input.temporadas-codigo').attr("id", itemName5);
			$('.cpTemporadas ul li:nth-child('+i3+') input.temporadas-titulo').attr("name", itemName6);
			$('.cpTemporadas ul li:nth-child('+i3+') input.temporadas-titulo').attr("id", itemName6);
			$('.cpTemporadas ul li:nth-child('+i3+') input.temporadas-link').attr("name", itemName7);
			$('.cpTemporadas ul li:nth-child('+i3+') input.temporadas-link').attr("id", itemName7);
		}

	}

	$('.cpTemporadas a.btn-tmAdd').click(function(){
		if($('.cpTemporadas ul li').length == 0){
			$('.cpTemporadas ul').html(tmItem3);
		} else {
			$('.cpTemporadas ul li:last-child').after(tmItem3);
		}
		$('.cpTemporadas .cp-tmRemove').css('display','block');
		tmItem3_update();

	});

	$('.cpTemporadas').delegate('.btn-tmRemove', 'click', function(){
		$(this).parent().parent().remove();
		tmItem3_update();

	});

	var tmUpdate = setInterval(function(){tmItem3_update()}, 600);

	// Ocultar Campos
	var postFilmes = function(display){
		$('#imagem').parent().parent().css('display',display);
		$('#capa').parent().parent().css('display',display);
		$('#audio').parent().parent().css('display',display);
		$('#qualidade').parent().parent().css('display',display);
		$('#ano-lancamento').parent().parent().css('display',display);
		$('#avaliacao').parent().parent().css('display',display);
		$('#classind').parent().parent().css('display',display);
		$('#status').parent().parent().css('display',display);
		$('#tempo').parent().parent().css('display',display);
		$('#trailer').parent().parent().css('display',display);
		$('.cpBaixar').parent().parent().css('display',display);
		$('.cpFilmes').parent().parent().css('display',display);

	}

	var postTemporadas = function(display){
		$('#imagem').parent().parent().css('display',display);
		$('#capa').parent().parent().css('display',display);
		$('#numero-temporadas').parent().parent().css('display',display);
		$('#numero-episodios').parent().parent().css('display',display);
		$('#transmissao').parent().parent().css('display',display);
		$('.cpTemporadas').parent().parent().css('display',display);

	}

	var postEpisodio = function(display){
		$('#imagem').parent().parent().css('display',display);
		$('#capa').parent().parent().css('display',display);
		$('#audio').parent().parent().css('display',display);
		$('#qualidade').parent().parent().css('display',display);
		$('#avaliacao').parent().parent().css('display',display);
		$('#classind').parent().parent().css('display',display);
		$('#nome-episodio').parent().parent().css('display',display);
		$('#ep-duracao').parent().parent().css('display',display);
		$('.cpBaixar').parent().parent().css('display',display);
		$('.cpFilmes').parent().parent().css('display',display);

	}

	postFilmes('none');
	postTemporadas('none');
	postEpisodio('none');

	vTipoPost = $("select#tipo-post option[selected='selected']").text();

	var tipoPost = function(tipoPost){
		if(tipoPost == 'Simples'){
			postFilmes('none');
			postTemporadas('none');
			postEpisodio('none');
		}
		if(tipoPost == 'Filme'){
			postTemporadas('none');
			postEpisodio('none');
			postFilmes('');
		}
		if(tipoPost == 'Temporadas'){
			postFilmes('none');
			postEpisodio('none');
			postTemporadas('');
		}
		if(tipoPost == 'Episodio'){
			postTemporadas('none');
			postFilmes('none');
			postEpisodio('');
		}

	}

	tipoPost(vTipoPost);

	$('#tipo-post').change(function(){
		vTipoPost = $('#tipo-post').val();
		tipoPost(vTipoPost);
	});

});