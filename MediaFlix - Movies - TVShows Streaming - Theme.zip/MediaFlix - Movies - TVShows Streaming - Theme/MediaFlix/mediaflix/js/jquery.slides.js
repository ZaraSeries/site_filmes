$(function(){

	$(".postsRelacionados .prSlide").jCarouselLite({
		btnPrev : '.prPrev',
		btnNext : '.prNext',
		auto    : 5500,
		speed   : 1000,
		visible : 3
	});

	jQuery.fn.extend({
		adjustHeight: function(){
			var element = $(this);
			var finalHeight = 0;

			$.each(element,function(i,compare){
				if($(compare).height() > finalHeight){
					finalHeight = $(compare).height();
				}
			});

			$.each(element,function(i,change){
				$(change).height(finalHeight);
			});

			return $(this);
		}
	});

	$('ul.le-temporadas>li').adjustHeight();
	$('ul.le-temporadas, ul.le-temporadas>li').adjustHeight();

	$(".le-temp").jCarouselLite({
		btnPrev : '.lePrev',
		btnNext : '.leNext',
		speed   : 1000,
		visible : 3
	});
});