$(function(){

	$("ul.videos li").css('display','none');
	$("ul.videos li.video1-code").css('display','block');

	$('ul.itens li').click(function(){
        var class1 = $(this).attr('class');

		if(class1 != 'video0'){
			$("ul.videos li").fadeOut();
			var src = $("ul.videos li." + class1 + "-code iframe").attr('data-src');
			$("ul.videos li." + class1 + "-code iframe").attr('src', src);
			$("ul.videos li." + class1 + "-code").fadeIn();
		}
	});

	$('.apagar-luz').click(function(){
		$('.apagar-luz').css('display', 'none');
		$('.acender-luz').css('display', 'block');
		$('.mascara').fadeIn(0);
	});

	$('.acender-luz').click(function(){
		$('.apagar-luz').css('display', 'block');
		$('.acender-luz').css('display', 'none');
		$('.mascara').fadeOut(0);
	});

	$('.bso-comentarios').click(function(){
		$('ul.bs-content li.bs-comentarios').css('display','block');
		$('ul.bs-content li.bs-postrelated').css('display','none');
		$('.blocosSingle .bs-seta').css('margin-left','130px');
	});

	$('.bs-opcoes .bso-postrelated').click(function(){
		$('ul.bs-content li.bs-comentarios').css('display','none');
		$('ul.bs-content li.bs-postrelated').css('display','block');
		$('.blocosSingle .bs-seta').css('margin-left','423px');
	});

});