<?php

	// MENU's
	if(function_exists('register_nav_menu')){
		register_nav_menu('topo_menu', 'Menu do Topo');
		register_nav_menu('rod_parceiros', 'Links de Parceiros');
	}
	
	// 
	function short_title($before = '', $after = '', $echo = true, $length = false){
		$title = get_the_title();
		$title = str_replace('&#45;', '-', $title);
		$title = str_replace('&#8211;', '-', $title);
		$title = str_replace('–', '-', $title);
		$title = str_replace('&ndash;', '-', $title);

		if ($length && is_numeric($length)){
			if(strlen($title) > $length){
				$after_ctl = true;
			}
			$title = substr($title, 0, $length);
		}

		if (strlen($title) > 0){
			if($after_ctl == true){
				$title = apply_filters('short_title', $before.$title.$after, $before, $after);
			}
			if($echo)
				echo $title;
			else
			
			return $title;
		}
	}

	// CAMPOS DOS POSTs
	$meta_box['post'] = array(
		'id' => 'campos_post',
		'title' => 'Campos da Postagem',
		'context' => 'normal',
		'priority' => 'high',
		'numtemporadas' => 10,
		'fields' => array(
			array('name' => 'Tipo do post','desc' => '','id' => 'tipo-post','type' => 'select', 'options' => array('Simples', 'Filme', 'Temporadas', 'Episodio'),'default' => ''),
			// Campos de Episódios
			array('name' => 'Nome do episódio','desc' => '','id' => 'nome-episodio','type' => 'text','default' => ''),
			array('name' => 'Duração','desc' => '','id' => 'ep-duracao','type' => 'text','default' => ''),
			// Campos de Filmes
			array('name' => 'Imagem (Miniatura)','desc' => '','id' => 'imagem','type' => 'text','default' => ''),
			array('name' => 'Capa (Img Grande)','desc' => '','id' => 'capa','type' => 'text','default' => ''),
			array('name' => '<small>[Tag]</small> Audio','desc' => '','id' => 'audio','type' => 'text','default' => ''),
			array('name' => '<small>[Tag]</small> Qualidade','desc' => '','id' => 'qualidade','type' => 'text','default' => ''),
			array('name' => 'Ano de Lançamento','desc' => '','id' => 'ano-lancamento','type' => 'text','default' => ''),
			array('name' => 'Avaliação','desc' => '','id' => 'avaliacao','type' => 'text','default' => ''),
			array('name' => 'Classificação','desc' => '','id' => 'classind','type' => 'text','default' => ''),
			array('name' => 'Status','desc' => '','id' => 'status','type' => 'text','default' => ''),
			array('name' => 'Tempo','desc' => '','id' => 'tempo','type' => 'text','default' => ''),
			array('name' => 'Trailer','desc' => '','id' => 'trailer','type' => 'textarea','default' => ''),
			array('name' => 'Baixar','desc' => '','id' => 'baixar','type' => 'baixar','default' => ''),
			array('name' => 'Filmes','desc' => '','id' => 'filmes','type' => 'filmes','default' => ''),
			// Campos de Temporadas
			array('name' => 'Número de Temporadas','desc' => '','id' => 'numero-temporadas','type' => 'text','default' => ''),	
			array('name' => 'Número de Episódios','desc' => '','id' => 'numero-episodios','type' => 'text','default' => ''),	
			array('name' => 'Transmissão','desc' => '','id' => 'transmissao','type' => 'text','default' => ''),	
			array('name' => 'Temporadas','desc' => '','id' => 'temporadas','type' => 'temporadas','default' => '')
		)
	);
// --------------------------------------------------		
	function plib_add_box() {
		global $meta_box;
		foreach($meta_box as $post_type => $value) {
			add_meta_box($value['id'], $value['title'], 'plib_format_box', $post_type, $value['context'], $value['priority']);
		}
	}
	function plib_format_box() {
		global $meta_box, $post;
		echo '<input type="hidden" name="plib_meta_box_nonce" value="', wp_create_nonce(basename(__FILE__)), '" />';
		echo '<table class="form-table">';
		foreach ($meta_box[$post->post_type]['fields'] as $field) {
			$meta = get_post_meta($post->ID, $field['id'], true);
			echo '<tr>'.
				  '<th style="width:20%"><label for="'. $field['id'] .'">'. $field['name']. '</label></th>'.
				  '<td>';
			switch ($field['type']) {
				case 'text':
					echo '<input type="text" name="'. $field['id']. '" id="'. $field['id'] .'" value="'. ($meta ? $meta : $field['default']) . '" size="30" style="width:97%" />'. '<br />'. $field['desc'];
					break;
				case 'textarea':
					
					echo '<textarea name="'. $field['id']. '" id="'. $field['id']. '" cols="60" rows="4" style="width:97%">'. ($meta ? $meta : $field['default']) . '</textarea>'. '<br />'. $field['desc'];
					break;
				case 'select':
					echo '<select';
					if(strpos($field['id'],'numtemp') !== false){echo ' id=numtemp ';}
					echo ' name="'. $field['id'] . '" id="'. $field['id'] . '">';
					foreach ($field['options'] as $option) {
						echo '<option '. ( $meta == $option ? ' selected="selected"' : '' ) . '>'. $option . '</option>';
					}
					echo '</select>';
					break;
				case 'radio':
					foreach ($field['options'] as $option) {
						echo '<input type="radio" name="' . $field['id'] . '" value="' . $option['value'] . '"' . ( $meta == $option['value'] ? ' checked="checked"' : '' ) . ' />' . $option['name'];
					}
					break;
				case 'checkbox':
					echo '<input type="checkbox" name="' . $field['id'] . '" id="' . $field['id'] . '"' . ( $meta ? ' checked="checked"' : '' ) . ' />';
					break;
				case 'baixar':

					echo '<div class="cpBaixar"><ul>';
					$baixar_n = 1;
					while($baixar_status!='off'){
					$baixar_nome[$baixar_n] = get_post_meta($post->ID, 'baixar'.$baixar_n.'-nome', true);
					$baixar_link[$baixar_n] = get_post_meta($post->ID, 'baixar'.$baixar_n.'-link', true);
					if($baixar_nome[$baixar_n] or $baixar_link[$baixar_n]){ ?>
						<li>
							<input type="text" name="<?php echo 'baixar'.$baixar_n.'-nome'; ?>" id="<?php echo 'baixar'.$baixar_n.'-nome'; ?>" class="baixar-nome" value="<?php echo $baixar_nome[$baixar_n]; ?>" size="30" style="width:97%" />
							<input type="text" name="<?php echo 'baixar'.$baixar_n.'-link'; ?>" id="<?php echo 'baixar'.$baixar_n.'-link'; ?>" class="baixar-link" value="<?php echo $baixar_link[$baixar_n]; ?>" size="30" style="width:97%" />
							<div class="cp-tmRemove"><a class="button btn-tmRemove">-</a><p>Remover os dois campos acima.</p></div>
						</li>
<?php
					$baixar_n++;
					} else {$baixar_status='off';}}
				
					echo '</ul><div class="cp-tmAdd"><a class="button-primary btn-tmAdd">+</a><p>Adiciona novo campo.</p></div></div>';

					break;
				case 'filmes':

					echo '<div class="cpFilmes"><ul>';
					$filmes_n = 1;
					while($filmes_status!='off'){
					$filme_nome[$filmes_n] = get_post_meta($post->ID, 'video'.$filmes_n.'-nome', true);
					$filme_code[$filmes_n] = get_post_meta($post->ID, 'video'.$filmes_n.'-code', true);
					if($filme_nome[$filmes_n] or $filme_code[$filmes_n]){ ?>
						<li>
							<input type="text" name="<?php echo 'video'.$filmes_n.'-nome'; ?>" id="<?php echo 'video'.$filmes_n.'-nome'; ?>" value="<?php echo $filme_nome[$filmes_n]; ?>" size="30" style="width:97%" />
							<textarea name="<?php echo 'video'.$filmes_n.'-code'; ?>" id="<?php echo 'video'.$filmes_n.'-code'; ?>" cols="60" rows="4" style="width:97%"><?php echo $filme_code[$filmes_n]; ?></textarea>
							<div class="cp-tmRemove"><a class="button btn-tmRemove">-</a><p>Remover os dois campos acima.</p></div>
						</li>
<?php
					$filmes_n++;
					} else {$filmes_status='off';}}
				
					echo '</ul><div class="cp-tmAdd"><a class="button-primary btn-tmAdd">+</a><p>Adiciona novo campo.</p></div></div>';

					break;
				case 'temporadas':

					echo '<div class="cpTemporadas"><ul>';
					
					$temporada2_s = 1;
					while($temporadas_status!='off'){
					$temporada2[$temporada2_s][1]['titulo'] = get_post_meta($post->ID, 's0'.$temporada2_s.'e01-titulo', true);
					
					if($temporada2[$temporada2_s][1]['titulo']){
						$temporada2_e  = 1;
						$temporada2_eN = 0;
						$temporadas_status2 = '';
						while($temporadas_status2!='off'){
							$temporada2[$temporada2_s][$temporada2_e]['codigo'] = get_post_meta($post->ID, 's0'.$temporada2_s.'e'.$temporada2_eN.$temporada2_e.'-codigo', true);
							$temporada2[$temporada2_s][$temporada2_e]['titulo'] = get_post_meta($post->ID, 's0'.$temporada2_s.'e'.$temporada2_eN.$temporada2_e.'-titulo', true);
							$temporada2[$temporada2_s][$temporada2_e]['link'] = get_post_meta($post->ID, 's0'.$temporada2_s.'e'.$temporada2_eN.$temporada2_e.'-link', true);
							
							if($temporada2[$temporada2_s][$temporada2_e]['titulo']){ ?>
						<li>
							<input type="text" name="<?php echo 's0'.$temporada2_s.'e'.$temporada2_eN.$temporada2_e.'-codigo'; ?>" id="<?php echo 's0'.$temporada2_s.'e'.$temporada2_eN.$temporada2_e.'-codigo'; ?>" class="temporadas-codigo" value="<?php echo $temporada2[$temporada2_s][$temporada2_e]['codigo']; ?>" size="30" style="width:97%" />
							<input type="text" name="<?php echo 's0'.$temporada2_s.'e'.$temporada2_eN.$temporada2_e.'-titulo'; ?>" id="<?php echo 's0'.$temporada2_s.'e'.$temporada2_eN.$temporada2_e.'-titulo'; ?>" class="temporadas-titulo" value="<?php echo $temporada2[$temporada2_s][$temporada2_e]['titulo']; ?>" size="30" style="width:97%" />
							<input type="text" name="<?php echo 's0'.$temporada2_s.'e'.$temporada2_eN.$temporada2_e.'-link'; ?>" id="<?php echo 's0'.$temporada2_s.'e'.$temporada2_eN.$temporada2_e.'-link'; ?>" class="temporadas-link" value="<?php echo $temporada2[$temporada2_s][$temporada2_e]['link']; ?>" size="30" style="width:97%" />
							<div class="cp-tmRemove"><a class="button btn-tmRemove">-</a><p>Remover os dois campos acima.</p></div>
						</li>
<?php
							$temporada2_e++;
							if($temporada2_e > 9){
								$temporada2_eN = '';
							}
						} else {$temporadas_status2 = 'off';}}
						
						$temporada2_s++;
					} else {$temporadas_status = 'off';}}
					
					echo '</ul><div class="cp-tmAdd"><a class="button-primary btn-tmAdd">+</a><p>Adiciona novo campo.</p></div></div>';

					break;
			}
			echo '<td>'.'</tr>';
		}
		echo '</table>';
	
		wp_enqueue_style('camposPostStyle', get_template_directory_uri().'/cpStyle.css');
		wp_enqueue_script('spp_zepto', get_template_directory_uri().'/js/zepto.min.js', array(), '', true);
		wp_enqueue_script('camposPostScript', get_template_directory_uri().'/js/cpScript.js', array(), '', true);

	}
	
	add_action('admin_menu', 'plib_add_box');
	function plib_save_data($post_id) {
		global $meta_box,  $post;
		if (!wp_verify_nonce($_POST['plib_meta_box_nonce'], basename(__FILE__))) {
			return $post_id;
		}
		if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
			return $post_id;
		}
		if ('page' == $_POST['post_type']) {
			if (!current_user_can('edit_page', $post_id)) {
				return $post_id;
			}
		} elseif (!current_user_can('edit_post', $post_id)) {
			return $post_id;
		}
		foreach ($meta_box[$post->post_type]['fields'] as $field) {
			$old = get_post_meta($post_id, $field['id'], true);
			$new = $_POST[$field['id']];
			if ($new && $new != $old) {
				update_post_meta($post_id, $field['id'], $new);
			} elseif ('' == $new && $old) {
				delete_post_meta($post_id, $field['id'], $old);
			}
		}
		
		$tipo_post = $_POST['tipo-post'];
		if($tipo_post == 'Filme' or $tipo_post == 'Episodio'){
			// Baixar
			$baixar2_n = 1;
			while($baixar2_status!='off'){
			$baixar2_new[$baixar2_n] = $_POST['baixar'.$baixar2_n.'-nome'];
			if($baixar2_new[$baixar2_n]){
			
				$baixar2_old = get_post_meta($post_id, 'baixar'.$baixar2_n.'-nome', true);
				
				if(!empty($baixar2_old) AND $baixar2_old != $baixar2_new[$baixar2_n]){
					update_post_meta($post_id,'baixar'.$baixar2_n.'-nome', $baixar2_new[$baixar2_n]);
				} else if(empty($baixar2_old)) {
					update_post_meta($post_id,'baixar'.$baixar2_n.'-nome', $baixar2_new[$baixar2_n]);
				}
				
				$baixar2_n++;
			} else {$baixar2_status='off';}}
			
			while($baixar3_status!='off'){
			$baixar3_old[$baixar2_n] = get_post_meta($post_id, 'baixar'.$baixar2_n.'-nome', true);
			if($baixar3_old[$baixar2_n]){
					delete_post_meta($post_id, 'baixar'.$baixar2_n.'-nome', $baixar3_old[$baixar2_n]);
				$baixar2_n++;
			} else {$baixar3_status='off';}}
			
			
			$baixar4_n = 1;
			while($baixar4_status!='off'){
			$baixar4_new[$baixar4_n] = $_POST['baixar'.$baixar4_n.'-link'];
			if($baixar4_new[$baixar4_n]){
			
				$baixar4_old = get_post_meta($post_id, 'baixar'.$baixar4_n.'-link', true);
				
				if(!empty($baixar4_old) AND $baixar4_old != $baixar4_new[$baixar4_n]){
					update_post_meta($post_id,'baixar'.$baixar4_n.'-link', $baixar4_new[$baixar4_n]);
				} else if(empty($baixar4_old)) {
					update_post_meta($post_id,'baixar'.$baixar4_n.'-link', $baixar4_new[$baixar4_n]);
				}
				
				$baixar4_n++;
			} else {$baixar4_status='off';}}
			
			while($baixar5_status!='off'){
			$baixar5_old[$baixar4_n] = get_post_meta($post_id, 'baixar'.$baixar4_n.'-link', true);
			if($baixar5_old[$baixar4_n]){
					delete_post_meta($post_id, 'baixar'.$baixar4_n.'-link', $baixar5_old[$baixar4_n]);
				$baixar4_n++;
			} else {$baixar5_status='off';}}
			
			// Filmes
			$filmes2_n = 1;
			while($filmes2_status!='off'){
			$filmes2_new[$filmes2_n] = $_POST['video'.$filmes2_n.'-nome'];
			if($filmes2_new[$filmes2_n]){
			
				$filmes2_old = get_post_meta($post_id, 'video'.$filmes2_n.'-nome', true);
				
				if(!empty($filmes2_old) AND $filmes2_old != $filmes2_new[$filmes2_n]){
					update_post_meta($post_id,'video'.$filmes2_n.'-nome', $filmes2_new[$filmes2_n]);
				} else if(empty($filmes2_old)) {
					update_post_meta($post_id,'video'.$filmes2_n.'-nome', $filmes2_new[$filmes2_n]);
				}
				
				$filmes2_n++;
			} else {$filmes2_status='off';}}
			
			while($filmes3_status!='off'){
			$filmes3_old[$filmes2_n] = get_post_meta($post_id, 'video'.$filmes2_n.'-nome', true);
			if($filmes3_old[$filmes2_n]){
					delete_post_meta($post_id, 'video'.$filmes2_n.'-nome', $filmes3_old[$filmes2_n]);
				$filmes2_n++;
			} else {$filmes3_status='off';}}
			
			
			$filmes4_n = 1;
			while($filmes4_status!='off'){
			$filmes4_new[$filmes4_n] = $_POST['video'.$filmes4_n.'-code'];
			if($filmes4_new[$filmes4_n]){
			
				$filmes4_old = get_post_meta($post_id, 'video'.$filmes4_n.'-code', true);
				
				if(!empty($filmes4_old) AND $filmes4_old != $filmes4_new[$filmes4_n]){
					update_post_meta($post_id,'video'.$filmes4_n.'-code', $filmes4_new[$filmes4_n]);
				} else if(empty($filmes4_old)) {
					update_post_meta($post_id,'video'.$filmes4_n.'-code', $filmes4_new[$filmes4_n]);
				}
				
				$filmes4_n++;
			} else {$filmes4_status='off';}}
			
			while($filmes5_status!='off'){
			$filmes5_old[$filmes4_n] = get_post_meta($post_id, 'video'.$filmes4_n.'-code', true);
			if($filmes5_old[$filmes4_n]){
					delete_post_meta($post_id, 'video'.$filmes4_n.'-code', $filmes5_old[$filmes4_n]);
				$filmes4_n++;
			} else {$filmes5_status='off';}}
			
		} else if($tipo_post == 'Temporadas'){
			// Temporadas
			$temporadas3_s = 1;
			
			while($temporadas3_status!='off'){
				$temporadas3_new[$temporadas3_s][1]['codigo'] = $_POST['s0'.$temporadas3_s.'e01-codigo'];
				$temporadas3_new[$temporadas3_s][1]['titulo'] = $_POST['s0'.$temporadas3_s.'e01-titulo'];
				$temporadas3_new[$temporadas3_s][1]['link']   = $_POST['s0'.$temporadas3_s.'e01-link'];
				
				if(!empty($temporadas3_new[$temporadas3_s][1]['codigo'])){
					$temporadas4_e = $temporadas3_e;
					$temporadas3_e = 1;
					$temporada3_eN = 0;
					$temporadas3_status2 = '';
					
					while($temporadas3_status2!='off'){
						$temporadas3_new[$temporadas3_s][$temporadas3_e]['codigo'] = $_POST['s0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-codigo'];
						$temporadas3_new[$temporadas3_s][$temporadas3_e]['titulo'] = $_POST['s0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-titulo'];
						$temporadas3_new[$temporadas3_s][$temporadas3_e]['link']   = $_POST['s0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-link'];
						
						$temporadas3_old[$temporadas3_s][$temporadas3_e]['codigo'] = get_post_meta($post_id, 's0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-codigo', true);
						$temporadas3_old[$temporadas3_s][$temporadas3_e]['titulo'] = get_post_meta($post_id, 's0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-titulo', true);
						$temporadas3_old[$temporadas3_s][$temporadas3_e]['link']   = get_post_meta($post_id, 's0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-link', true);
						
						if(!empty($temporadas3_new[$temporadas3_s][$temporadas3_e]['codigo']) AND !empty($temporadas3_new[$temporadas3_s][$temporadas3_e]['titulo']) AND !empty($temporadas3_new[$temporadas3_s][$temporadas3_e]['link'])){
							// Código
							if(!empty($temporadas3_old[$temporadas3_s][$temporadas3_e]['codigo']) AND $temporadas3_old[$temporadas3_s][$temporadas3_e]['codigo'] != $temporadas3_new[$temporadas3_s][$temporadas3_e]['codigo']){
								update_post_meta($post_id,'s0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-codigo', $temporadas3_new[$temporadas3_s][$temporadas3_e]['codigo']);
							} else if(empty($temporadas3_old[$temporadas3_s][$temporadas3_e]['codigo'])) {
								update_post_meta($post_id,'s0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-codigo', $temporadas3_new[$temporadas3_s][$temporadas3_e]['codigo']);
							}
							
							// Titulo
							if(!empty($temporadas3_old[$temporadas3_s][$temporadas3_e]['titulo']) AND $temporadas3_old[$temporadas3_s][$temporadas3_e]['titulo'] != $temporadas3_new[$temporadas3_s][$temporadas3_e]['titulo']){
								update_post_meta($post_id,'s0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-titulo', $temporadas3_new[$temporadas3_s][$temporadas3_e]['titulo']);
							} else if(empty($temporadas3_old[$temporadas3_s][$temporadas3_e]['titulo'])) {
								update_post_meta($post_id,'s0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-titulo', $temporadas3_new[$temporadas3_s][$temporadas3_e]['titulo']);
							}
							
							// Link
							if(!empty($temporadas3_old[$temporadas3_s][$temporadas3_e]['link']) AND $temporadas3_old[$temporadas3_s][$temporadas3_e]['link'] != $temporadas3_new[$temporadas3_s][$temporadas3_e]['link']){
								update_post_meta($post_id,'s0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-link', $temporadas3_new[$temporadas3_s][$temporadas3_e]['link']);
							} else if(empty($temporadas3_old[$temporadas3_s][$temporadas3_e]['link'])) {
								update_post_meta($post_id,'s0'.$temporadas3_s.'e'.$temporada3_eN.$temporadas3_e.'-link', $temporadas3_new[$temporadas3_s][$temporadas3_e]['link']);
							}
							
							$temporadas3_e++;
							if($temporadas3_e > 9){
								$temporada3_eN = '';
							}
						} else {
							$temporadas3_status2 = 'off';
						}
					}
					
					$temporadas3_s++;
				} else {
					$temporadas3_status = 'off';
				}
			}
		
			$temporadas4_s = 1;
			$temporadas4_noExist = 0;
			
			while($temporadas4_status != 'off'){
				$temporadas4_old[$temporadas4_s][1]['codigo'] = get_post_meta($post_id, 's0'.$temporadas4_s.'e01-codigo', true);
				$temporadas4_old[$temporadas4_s][1]['titulo'] = get_post_meta($post_id, 's0'.$temporadas4_s.'e01-titulo', true);
				$temporadas4_old[$temporadas4_s][1]['link']   = get_post_meta($post_id, 's0'.$temporadas4_s.'e01-link', true);
				
				if(!empty($temporadas4_old[$temporadas4_s][1]['codigo'])){
					$temporadas4_e = 1;
					$temporada4_eN = 0;
					$temporadas3_status2 = '';
					
					while($temporadas3_status2!='off'){
						$temporadas4_noExist = 0;
						$temporadas4_new[$temporadas4_s][$temporadas4_e]['codigo'] = $_POST['s0'.$temporadas4_s.'e'.$temporada4_eN.$temporadas4_e.'-codigo'];
						$temporadas4_new[$temporadas4_s][$temporadas4_e]['titulo'] = $_POST['s0'.$temporadas4_s.'e'.$temporada4_eN.$temporadas4_e.'-titulo'];
						$temporadas4_new[$temporadas4_s][$temporadas4_e]['link']   = $_POST['s0'.$temporadas4_s.'e'.$temporada4_eN.$temporadas4_e.'-link'];
						
						$temporadas4_old[$temporadas4_s][$temporadas4_e]['codigo'] = get_post_meta($post_id, 's0'.$temporadas4_s.'e'.$temporada4_eN.$temporadas4_e.'-codigo', true);
						$temporadas4_old[$temporadas4_s][$temporadas4_e]['titulo'] = get_post_meta($post_id, 's0'.$temporadas4_s.'e'.$temporada4_eN.$temporadas4_e.'-titulo', true);
						$temporadas4_old[$temporadas4_s][$temporadas4_e]['link']   = get_post_meta($post_id, 's0'.$temporadas4_s.'e'.$temporada4_eN.$temporadas4_e.'-link', true);
						
						if(empty($temporadas4_new[$temporadas4_s][$temporadas4_e]['codigo'])){
							if(empty($temporadas4_new[$temporadas4_s][$temporadas4_e]['codigo']) AND !empty($temporadas4_old[$temporadas4_s][$temporadas4_e]['codigo'])){
								// Código
								delete_post_meta($post_id,'s0'.$temporadas4_s.'e'.$temporada4_eN.$temporadas4_e.'-codigo',$temporadas4_old[$temporadas4_s][$temporadas4_e]['codigo']);
							} else {
								$temporadas4_noExist++;
							}
							
							if(empty($temporadas4_new[$temporadas4_s][$temporadas4_e]['titulo']) AND !empty($temporadas4_old[$temporadas4_s][$temporadas4_e]['titulo'])){
								// Titulo
								delete_post_meta($post_id, 's0'.$temporadas4_s.'e'.$temporada4_eN.$temporadas4_e.'-titulo', $temporadas4_old[$temporadas4_s][$temporadas4_e]['titulo']);
							} else {
								$temporadas4_noExist++;
							}
							
							if(empty($temporadas4_new[$temporadas4_s][$temporadas4_e]['link']) AND !empty($temporadas4_old[$temporadas4_s][$temporadas4_e]['link'])){
								// Link
								delete_post_meta($post_id,'s0'.$temporadas4_s.'e'.$temporada4_eN.$temporadas4_e.'-link',$temporadas4_old[$temporadas4_s][$temporadas4_e]['link']);
							} else {
								$temporadas4_noExist++;
							}
							
							if($temporadas4_noExist >= 1){
								$temporadas3_status2 = 'off';
							}
						}
						
						$temporadas4_e++;
						if($temporadas4_e > 9){
							$temporada4_eN = '';
						}
					}
					
					$temporadas4_s++;
				} else {
					$temporadas4_status = 'off';
				}
			}
		}
	}
	
	add_action('save_post', 'plib_save_data');


	// OPÇÕES DO TEMA
	add_action( 'admin_menu', 'register_my_custom_menu_page' );

	function register_my_custom_menu_page(){
		add_menu_page( 'Opções do tema', 'Opções do tema', 'manage_options', 'theme_options', 'theme_panel_options', '', 61 ); 
	}

	function theme_panel_options(){
?>
<div class="wrap">
	<h2>Opções do Tema</h2>

	<form method="post" action="options.php">
		<?php wp_nonce_field('update-options') ?>
		<style>
			.opcoes-tema {max-width: 780px;}
			.opcoes-tema input, .opcoes-tema textarea {width: 97%;}
		</style>
		<table class="form-table opcoes-tema">
			<tbody>
				<tr>
					<td valign="top">
						<strong>Cor do Tema:</strong>
					</td>

					<td valign="top">
						<select name="cor_tema" id="default_role">
							<?php if(get_option('cor_tema')){ ?>
							<option selected="selected" value="<?php echo get_option('cor_tema'); ?>"><?php echo ucfirst(get_option('cor_tema')); ?></option>
							<?php } ?>
							<option value="Selecione">Selecione uma cor</option>
							<option value="amarelo">Amarelo</option>
							<option value="azul">Azul</option>
							<option value="laranja">Laranja</option>
							<option value="verde">Verde</option>
							<option value="vermelho">Vermelho</option>
						</select>
					</td>
				</tr>

				<tr>
					<td valign="top">
						<strong>Link da Logo:</strong>
					</td>

					<td valign="top">
						<input type="text" name="link_logo" value="<?php echo get_option('link_logo'); ?>" />
					</td>
				</tr>

				<tr>
					<td valign="top">
						<strong>Link do Twitter:</strong>
					</td>

					<td valign="top">
						<input type="text" name="link_twitter" value="<?php echo get_option('link_twitter'); ?>" />
					</td>
				</tr>

				<tr>
					<td valign="top">
						<strong>Link do Facebook:</strong>
					</td>

					<td valign="top">
						<input type="text" name="link_facebook" value="<?php echo get_option('link_facebook'); ?>" />
					</td>
				</tr>
				
				<tr>
					<td valign="top">
						<strong>Link do Google+:</strong>
					</td>

					<td valign="top">
						<input type="text" name="link_googleplus" value="<?php echo get_option('link_googleplus'); ?>" />
					</td>
				</tr>
				
				<tr>
					<td valign="top">
						<strong>Link do Feed RSS:</strong>
					</td>

					<td valign="top">
						<input type="text" name="link_feed" value="<?php echo get_option('link_feed'); ?>" />
					</td>
				</tr>
				
				<tr>
					<td valign="top">
						<strong>Link do YouTube:</strong>
					</td>

					<td valign="top">
						<input type="text" name="link_youtube" value="<?php echo get_option('link_youtube'); ?>" />
					</td>
				</tr>

				<tr>
					<td valign="top">
						<strong>Publicidade Rodapé:</strong>
					</td>

					<td valign="top">
						<textarea cols="63" rows="3" id="pub_rod1" name="pub_rod1" placeholder="Código do Anuncio 01"><?php echo get_option('pub_rod1'); ?></textarea>
						<textarea cols="63" rows="3" id="pub_rod2" name="pub_rod2" placeholder="Código do Anuncio 02"><?php echo get_option('pub_rod2'); ?></textarea>
						<textarea cols="63" rows="3" id="pub_rod3" name="pub_rod3" placeholder="Código do Anuncio 03"><?php echo get_option('pub_rod3'); ?></textarea>
					</td>
				</tr>

				<tr>
					<td valign="top">
						<p><strong>Códigos no Rodapé da página:</strong><br />Todos os códigos deste campo irão ser inseridos antes da tag "<<small>'</small>/body>" no dinal da página.</p>
						<!-- Não remover a "'" (aspa simples) do texto "<'/body>" na linha acima. -->
					</td>

					<td valign="top">
						<textarea cols="63" rows="12" id="cod_rodape" name="cod_rodape"><?php echo get_option('cod_rodape'); ?></textarea>
					</td>
				</tr>
			</tbody>
		</table>

		<p class="submit">
			<input name="Submit" class="button-primary" value="Salvar Mudanças" type="submit">
			<input type="hidden" name="action" value="update" />
			<input type="hidden" name="page_options" value="cor_tema,link_logo,link_twitter,link_facebook,link_googleplus,link_feed,link_youtube,pub_rod1,pub_rod2,pub_rod3,cod_rodape" />
		</p>
	</form>
</div>
<?php
	}
