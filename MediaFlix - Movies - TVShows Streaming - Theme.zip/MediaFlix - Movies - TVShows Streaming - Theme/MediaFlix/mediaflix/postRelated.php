<div class="postsRelacionados">
	<div class="prControle">
		<div class="prPrev" style="float:left"><img src="<?php bloginfo('template_url'); ?>/imagens/prPrev.png" alt="Anterior" /></div>
		<div class="prNext"><img src="<?php bloginfo('template_url'); ?>/imagens/prNext.png" alt="Proximo" /></div>
	</div>

	<div class="prSlide">
		<ul>
<?php
			$categories = get_the_category($post->ID);
			if ($categories) {  $category_ids = array();  
			foreach($categories as $individual_category)  
				$category_ids[] = $individual_category->term_id; 

			$args = array( 
				'category__in' => $category_ids[0], 
				'post__not_in' => array($post->ID), 
				'showposts' => 9,
				'caller_get_posts' => 1 
			); 

			$my_query = new wp_query($args); 

			if( $my_query->have_posts() ) { 
				$count=1;
				while ($my_query->have_posts()) { 
				$my_query->the_post();

				$ratings_average = get_post_meta($post->ID, 'ratings_average', true);

				if($ratings_average == 0){
					$avaliacao_geral = "Nenhuma avaliação";
				} else if($ratings_average == 1){
					$avaliacao_geral = "Avaliação geral: Péssimo";
				} else if($ratings_average == 2){
					$avaliacao_geral = "Avaliação geral: Ruim";
				} else if($ratings_average == 3){
					$avaliacao_geral = "Avaliação geral: Mediano";
				} else if($ratings_average == 4){
					$avaliacao_geral = "Avaliação geral: Muito Bom";
				} else if($ratings_average == 5){
					$avaliacao_geral = "Avaliação geral: Excelente";
				}
?>
			<li class="pr-miniatura">
				<div class="pr-img">
					<a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><img src="<?php echo get_post_meta($post->ID, 'imagem', true); ?>" alt="<?php the_title(); ?>" title="<?php the_title(); ?>" /></a>
				</div>
				
				<h3 class="pr-titulo"><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php short_title('','..',true, '20');  ?></a></h3>
				<p class="pr-sinopse"><?php echo strip_tags(substr(get_the_content(''), 0, 107).'...'); ?></p>
				<a href="<?php the_permalink(); ?>" title="Assistir Agora" class="pr-assistirAgora">Assistir Agora</a>

				<div class="pr-avalicao"><b><?php echo $avaliacao_geral; ?></b></div>
			</li>
		<?php $count ++; ?>
		<?php }
					wp_reset_query();
				} 
			} 
		?>
		</ul>
	</div>
</div>