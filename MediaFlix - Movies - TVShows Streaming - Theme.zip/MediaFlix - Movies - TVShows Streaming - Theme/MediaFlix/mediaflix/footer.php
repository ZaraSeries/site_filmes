<ul class="pubRodape">
	<?php if(get_option('pub_rod1')){ ?><li><?php echo get_option('pub_rod1'); ?></li><?php } ?>
	<?php if(get_option('pub_rod2')){ ?><li><?php echo get_option('pub_rod2'); ?></li><?php } ?>
	<?php if(get_option('pub_rod3')){ ?><li><?php echo get_option('pub_rod3'); ?></li><?php } ?>
</ul>

<div class="rodape">
	<div class="center">
		<div class="parceiros">
			<div class="rdp-titulo">SEJA UM <span>PARCEIRO!</span></div>

			<ul>
			<?php
				$args = array(
					'container'       => '',
					'fallback_cb'     => '',
					'echo'            => true,
					'link_before'     => '',
					'link_after'      => '',
					'items_wrap'      => '%3$s',
					'theme_location'  => 'rod_parceiros'
				);

				wp_nav_menu($args);
			?>
			</ul>
		</div>

		<div class="rdp-right">

			<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>" class="rdp-logo"><?php bloginfo( 'name'); ?></a>

			<ul class="rdp-redessociais">
				<?php if(get_option('link_twitter')){ ?><li><a href="<?php echo get_option('link_twitter'); ?>"><img src="<?php bloginfo('template_url'); ?>/imagens/rodape-icon_twitter.jpg" alt="Twitter" /></a></li><?php } ?>
				<?php if(get_option('link_facebook')){ ?><li><a href="<?php echo get_option('link_facebook'); ?>"><img src="<?php bloginfo('template_url'); ?>/imagens/rodape-icon_facebook.jpg" alt="Facebook" /></a></li><?php } ?>
				<?php if(get_option('link_googleplus')){ ?><li><a href="<?php echo get_option('link_googleplus'); ?>"><img src="<?php bloginfo('template_url'); ?>/imagens/rodape-icon_googleplus.jpg" alt="Google+" /></a></li><?php } ?>
				<?php if(get_option('link_feed')){ ?><li><a href="<?php echo get_option('link_feed'); ?>"><img src="<?php bloginfo('template_url'); ?>/imagens/rodape-icon_rss.jpg" alt="Feed RSS" /></a></li><?php } ?>
				<?php if(get_option('link_youtube')){ ?><li><a href="<?php echo get_option('link_youtube'); ?>"><img src="<?php bloginfo('template_url'); ?>/imagens/rodape-icon_youtube.jpg" alt="Youtube" /></a></li><?php } ?>
			</ul>

			<div class="copyright">Todos os direitos reservados 2015 - <?php bloginfo('name'); ?>.</div>
			<div class="r-autor">Tema Wordpress Desenvolvido por <a href="http://www.wpires.com/" target="_blank" title="Desenvolvido por WPires.com">WPires.com</a>.</div>
		</div>
	</div>
</div>

<div class="mascara"></div>

<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.jcarousellite.js"></script>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.funcoes.js"></script>

<?php if(is_single()){ ?>
<script type="text/javascript" src="<?php bloginfo('template_url'); ?>/js/jquery.slides.js"></script>
<?php } else { ?>
<script type="text/javascript">
$(function(){
	$(".slideUL").jCarouselLite({
		btnPrev : '.slidePrev',
		btnNext : '.slideNext',
		auto    : 10000,
		speed   : 600,
		visible : 1
	});
});
</script>
<?php } ?>

<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/pt_BR/sdk.js#xfbml=1&version=v2.3";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>

<?php wp_footer(); ?>
<?php echo get_option('cod_rodape'); ?>
</body>
</html>