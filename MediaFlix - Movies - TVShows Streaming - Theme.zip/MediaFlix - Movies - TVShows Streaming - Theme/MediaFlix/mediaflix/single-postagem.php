<div class="theSingle">
	<div class="tempContent">
		<h1 class="tc-titulo"><?php the_title(); ?></h1>
		<div class="tc-sinopse"><?php the_content(); ?></div>
	</div>

	<div class="blocosSingle">
		<ul class="bs-opcoes">
			<li class="bso-comentarios"><img src="<?php bloginfo('template_url'); ?>/imagens/icon-comentarios.jpg" alt="Deixe seu comentário"/><span>Deixe seu comentário</span></li>
			<li class="bso-postrelated"><img src="<?php bloginfo('template_url'); ?>/imagens/icon-postsRelacionados.jpg" alt="Postagens relacionadas"/><span>Postagens Relacionadas</span></li>
			<li><img src="<?php bloginfo('template_url'); ?>/imagens/icon-visualizacoes.jpg" alt="Visualizações"/><?php if($the_views and $the_views >= 0){ echo $the_views; } else { echo '0'; } ?><span> Visualizações</span></li>
		</ul>
		<div class="bs-seta" style="margin-left: 423px;"></div>

		<ul class="bs-content">
			<li class="bs-comentarios">
				<div class="fb-comments" data-href="<?php the_permalink() ?>" data-width="885" data-numposts="5" data-colorscheme="dark"></div>
			</li>
			
			<li class="bs-postrelated"><?php include('postRelated.php'); ?></li>
		</ul>
	</div>
</div>