<?php
	get_header();
?>

<div class="single">
	<div class="breadcrumb"><?php if(function_exists('bcn_display')){ bcn_display(); } ?></div>

	<div class="theSingle">
		<div class="tempContent">
			<h1 class="tc-titulo">Página não encontrada!</h1>
			<div class="tc-sinopse">
				<p>Desculpe! Mas o filme ou série pesquisado não foi encontrado.</p>
			</div>
		</div>
	</div>
</div>

<?php
	get_footer();
?>