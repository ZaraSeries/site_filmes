<?php

	get_header();

	if(have_posts()):while(have_posts()):the_post();
	$the_views = get_post_meta($post->ID, 'views', true)+1;

	if(!empty($the_views)){
		$the_views+1;
		update_post_meta($post->ID,'views', $the_views);
	} else {
		update_post_meta($post->ID,'views', '0');
	}

	$post_cats = wp_get_post_categories(get_the_ID(), NULL);
	sort($post_cats, SORT_NUMERIC);

?>

<div class="single">
	<div class="breadcrumb"><?php if(function_exists('bcn_display')){ bcn_display(); } ?></div>

<?php
		$tipoPost = get_post_meta($post->ID, 'tipo-post', true);

		if($tipoPost == '' or $tipoPost == 'Simples')
			include('single-postagem.php');

		else if($tipoPost == 'Filme')
			include('single-filmes.php');

		else if($tipoPost == 'Temporadas')
			include('single-temporadas.php');

		else if($tipoPost == 'Episodio')
			include('single-episodio.php');

?>
</div>

<?php endwhile; else:endif; wp_reset_query(); ?>

<?php get_footer(); ?>