<div class="boxTemporada">
	<div class="temporadaContent">
		<h1 class="tc-titulo"><?php the_title(); ?></h1>
		<div class="tc-sinopse"><?php the_content(); ?></div>
	</div>

	<div class="temporadaInformacoes">
		<div class="ti-genero">
			<div class="ti-titulo">Gênero</div>

			<ul class="theCategory">
<?php
				$categories = get_the_category();
				$separator = ' ';
				$output = '';
				if($categories){
					foreach($categories as $category) {
						$output .= '<li><a href="'.get_category_link( $category->term_id ).'" title="' . esc_attr( sprintf( __( "View all posts in %s" ), $category->name ) ) . '">'.$category->cat_name.'</a><span class="icon"></span></li>'.$separator;
					}
				echo trim($output, $separator);
				}
?>
			</ul>
		</div>

		<div class="ti-temporadas">
			<div class="ti-titulo">Temporadas</div>

			<div class="ti-info"><?php echo get_post_meta($post->ID, 'numero-temporadas', true); ?> Temporadas</div>
		</div>

		<div class="ti-episodios">
			<div class="ti-titulo">N° Episódios</div>
			<div class="ti-info"><?php echo get_post_meta($post->ID, 'numero-episodios', true); ?> Episódios</div>
		</div>

		<div class="ti-transmissao">
			<div class="ti-titulo">Transmissão</div>
			<div class="ti-info"><?php echo get_post_meta($post->ID, 'transmissao', true); ?></div>
		</div>
	</div>

	<div class="listaEpisodios">
		<div class="le-head">
			<div class="le-reportarErro"><?php if(function_exists('ReportPageErrors')){ echo ReportPageErrors(); } ?></div>

			<div class="le-titulo">Lista de Episódios</div>

			<div class="le-descricao">
				<p>Selecione o episódio que gostaria de saber mais<br />Reporte qualquer link que esteja quebrado, ajude-nos a manter o blog atualizado.</p>
			</div>
		</div>

		<div class="leControle">
			<div class="lePrev" style="float:left"></div>
			<div class="leNext"></div>
		</div>

		<div class="le-temp">
		<ul class="le-temporadas">
<?php
		$s = 1;
		while($status1!='off'){
		$temporada[$s][1]['titulo'] = get_post_meta($post->ID, 's0'.$s.'e01-titulo', true);

		if($temporada[$s][1]['titulo']){ ?>
			<li class="le-temporada">
				<div class="let-titulo"><?php echo $s; ?>° Temporada</div>
				
				<div class="let-episodios">
<?php
			$temporada_e   = 1;
			$temporada_eN = 0;
			$status2       = '';
			while($status2!='off'){
				$temporada[$s][$temporada_e]['titulo'] = get_post_meta($post->ID, 's0'.$s.'e'.$temporada_eN.$temporada_e.'-titulo', true);
				$temporada[$s][$temporada_e]['link'] = get_post_meta($post->ID, 's0'.$s.'e'.$temporada_eN.$temporada_e.'-link', true);
				
				if($temporada[$s][$temporada_e]['titulo']){ ?>
					<div class="let-epis"><a href="<?php echo $temporada[$s][$temporada_e]['link']; ?>"><?php echo 'S0'.$s.'E'.$temporada_eN.$temporada_e.' - "'.$temporada[$s][$temporada_e]['titulo'].'"'; ?></a></div>
<?php
				$temporada_e++;
				if($temporada_e > 9){
					$temporada_eN = '';
				}
			} else {$status2 = 'off';}} ?>
				</div>
			</li>
<?php
		$s++;
		} else {$status1 = 'off';}} ?>
		</ul>
		</div>	
	</div>

	<div class="blocosSingle">
		<ul class="bs-opcoes">
			<li class="bso-comentarios"><img src="<?php bloginfo('template_url'); ?>/imagens/icon-comentarios.jpg" alt="Deixe seu comentário"/><span>Deixe seu comentário</span></li>
			<li class="bso-postrelated"><img src="<?php bloginfo('template_url'); ?>/imagens/icon-seriesRelacionadas.jpg" alt="Outras Séries"/><span>Outras Séries</span></li>
			<li><img src="<?php bloginfo('template_url'); ?>/imagens/icon-visualizacoes.jpg" alt="Visualizações"/><?php if($the_views and $the_views >= 0){ echo $the_views; } else { echo '0'; } ?><span> Visualizações</span></li>
		</ul>
		<div class="bs-seta" style="margin-left: 423px;"></div>

		<ul class="bs-content">
			<li class="bs-comentarios">
				<div class="fb-comments" data-href="<?php the_permalink() ?>" data-width="885" data-numposts="5" data-colorscheme="dark"></div>
			</li>
			
			<li class="bs-postrelated"><?php include('postRelated.php'); ?></li>
		</ul>
	</div>
</div>