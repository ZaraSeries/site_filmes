<?php get_header(); ?>

<div class="conteudo index">
	<div class="ihead">
		<div class="ap-select">
			<div class="fSelect">
				<p><b>últimos Lançamentos</b><br /><span>Veja os  últimos seriados e filmes atualizados</span></p>
			</div>

			<ul class="fOpcoes">
				<li><a href="<?php echo get_category_link(get_cat_ID('series')); ?>">Últimos Episódios</a></li>
				<li><a href="<?php echo get_category_link(get_cat_ID('filmes')); ?>">Últimos Filmes</a></li>
			</ul>
		</div>

		<div class="qPosts">
			<div class="qPosts-icon"></div>
<?php
		$numseries = 0;
		$numseries = $wpdb->get_var("SELECT count FROM wp_term_taxonomy WHERE term_taxonomy_id = '10' ");
		if(0 < $numseries)
			$numseries = number_format($numseries);
		
		$numposts = $wpdb->get_var("SELECT count(*) FROM $wpdb->posts WHERE post_status = 'publish' AND post_type = 'post'");

		if(0 < $numposts)
			$numposts = number_format($numposts);
?>
			<p><b><?php echo $numposts-$numseries; ?> Filmes</b><br /><span>Filmes postados no site</span></p>
		</div>

		<div class="qPosts">
			<div class="qPosts-icon"></div>
			<p><b><?php echo $numseries; ?> Episódios</b><br /><span>De seriados postados no site</span></p>
		</div>
	</div>

	<div class="miniaturas">
<?php
		query_posts($query_string);
		if(have_posts()):while(have_posts()):the_post();
		$url_imagem = get_post_meta($post->ID, 'imagem', true);
		$audio      = get_post_meta($post->ID, 'audio', true);
		$qualidade  = get_post_meta($post->ID, 'qualidade', true);
		$p_visitas  = get_post_meta($post->ID, 'views', true);
		$rand = rand(0, 999999); ?>

		<div class="miniatura">
			<div class="tooltip">
				<div class="tt-content">
					<div class="tt-theContent">
						<h3 class="tt-titulo"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>

						<div class="tt-infos">
							<div class="iCats"><?php the_category(', '); ?></div>
							<div class="iClassind"><?php echo get_post_meta($post->ID, 'classind', true); ?></div>
							<div class="iDuracao"><?php echo get_post_meta($post->ID, 'tempo', true); ?> min.</div>
							<div class="iAno"><?php echo get_post_meta($post->ID, 'ano-lancamento', true); ?></div>
						</div>
			
						<div class="tt-sinopse">
							<p><?php echo strip_tags(get_the_content()); ?></p>
							<a href="<?php the_permalink(); ?>" class="maisInfos">Mais Informações...</a>
						</div>
					</div>
				</div>

				<div class="tt-seta"></div>
			</div>

			<h2><a href="<?php the_permalink(); ?>" title="<?php the_title(); ?>"><?php short_title('','..',true, '24'); ?></a></h2>

			<div class="img">
				<div class="mTag">
					<?php if($audio != ""){ ?>
					<span><?php echo $audio; ?></span>
					<?php } ?>
					<?php if($qualidade != ""){ ?>
					<span><?php echo $qualidade; ?></span>
					<?php } ?>
				</div>

				<img src="<?php echo $url_imagem; ?>" alt="<?php the_title(); ?>" title="<?php the_title(); ?>" />
				<a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
			</div>

			<div class="mInfo">
				<a href="#" class="comentarios"><span class="fb-comments-count" data-href="<?php the_permalink(); ?>"></span></a>
				<div class="mAutor"><a href="<?php echo esc_url( get_author_posts_url( get_the_author_meta( 'ID' ) ) ); ?>" class="autor" rel="author"><?php echo ucwords(get_the_author_link()); ?></a></div>
				<div class="mViews"><?php if($p_visitas and $p_visitas >= 0){ echo $p_visitas; } else { echo '0'; } ?> visitas</div>
			</div>
		</div>
<?php	endwhile;

		if(function_exists('wp_pagenavi')){
			wp_pagenavi();
		} else {
			echo '<div class="wp-pagenavi">';
			posts_nav_link('&nbsp;', '&laquo; Página Anterior', 'Próxima Página &raquo;');
			echo '</div>';
		}

		else:endif; wp_reset_query(); ?>
	</div>
</div>

<script src="<?php bloginfo('template_url'); ?>/js/jquery.js"></script>
<script src="<?php bloginfo('template_url'); ?>/js/jquery.miniaturas.js"></script>

<?php get_footer(); ?>