<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head profile="http://gmpg.org/xfn/11">
	<title><?php if(is_single()){ wp_title(''); echo ' | '; } bloginfo('name'); ?></title>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
	<link rel="shortcut icon" href="<?php bloginfo('template_url'); ?>/favicon.png" />
	<link href="<?php bloginfo('stylesheet_url'); ?>" rel="stylesheet" type="text/css" />
	<?php if($_GET['c'] == 1){ ?>
	<link href="<?php bloginfo('template_url'); ?>/css/style-verde.css" rel="stylesheet" type="text/css" />
	<?php } else if($_GET['c'] == 2){ ?>
	<link href="<?php bloginfo('template_url'); ?>/css/style-vermelho.css" rel="stylesheet" type="text/css" />
	<?php } else if($_GET['c'] == 3){ ?>
	<link href="<?php bloginfo('template_url'); ?>/css/style-azul.css" rel="stylesheet" type="text/css" />
	<?php } else if($_GET['c'] == 4){ ?>
	<link href="<?php bloginfo('template_url'); ?>/css/style-amarelo.css" rel="stylesheet" type="text/css" />
	<?php } else if(get_option('cor_tema')){ ?>
	<link href="<?php bloginfo('template_url'); ?>/css/style-<?php echo get_option('cor_tema'); ?>.css" rel="stylesheet" type="text/css" />
	<?php } else { ?>
	<link href="<?php bloginfo('template_url'); ?>/css/style-laranja.css" rel="stylesheet" type="text/css" />
	<?php } ?>
	<link rel="pingback" href="<?php bloginfo('pingback_url'); ?>" />
	<?php wp_head(); ?>
	<?php if(!is_single() and !is_page()){ ?>
	<style>
<?php
	$style_n = 1;
	query_posts($query_string.'posts_per_page=6&cat=slide');
	if(have_posts()):while(have_posts()):the_post();

	$capa = get_post_meta($post->ID, 'capa', true);
	if($capa){ ?>
	.slide<?php echo $style_n; ?> {background:url('<?php echo $capa; ?>') no-repeat top center;}
<?php } $style_n++; endwhile; else:endif; wp_reset_query(); ?>
	</style>

	<?php } else { ?>
	<style>.singleCapa {background:url('<?php echo get_post_meta($post->ID, 'capa', true); ?>') no-repeat top center;}</style>
	<?php } ?>

	<?php if(get_option('link_logo')){ ?>
	<style>.topo a.logo, .rodape .rdp-logo {background-image: url('<?php echo get_option('link_logo'); ?>');}</style>
	<?php } ?>
</head>

<body>
<div class="topoCpsl<?php if(is_page()){ echo ' tp-pagina'; } ?>">
	<?php if(!is_single() and !is_page()){ ?>
	<div class="slide">
		<div class="slideControles">
			<div class="slidePrev"></div>
			<div class="slideNext"></div>
		</div>

		<div class="slideUL">
			<ul>
<?php
		$post_n = 1;
		query_posts($query_string.'posts_per_page=6&cat=slide');
		if(have_posts()):while(have_posts()):the_post();

		$url_imagem = get_post_meta($post->ID, 'imagem', true);
		$audio      = get_post_meta($post->ID, 'audio', true);
		$qualidade  = get_post_meta($post->ID, 'qualidade', true); ?>
				<li class="slide<?php echo $post_n; ?>">
					<div class="slideCenter">
						<div class="slideInfos">
							<h2><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h2>
							<p><?php echo strip_tags(substr(get_the_content(''), 0, 110).'..'); ?></p>
							<a href="<?php the_permalink(); ?>" class="leiaMais">Continue lendo...</a>
						</div>
					</div>
				</li>
	<?php $post_n++; endwhile; else:endif; wp_reset_query(); ?>
			</ul>
		</div>
	</div>
	<?php } else if(!is_page()){

	query_posts('p='.get_the_ID());
	global $more; $more = 0;
	while (have_posts()) : the_post(); ?>
	<div class="singleCapa">
		<div class="center">
			<div class="sc-infos">
				<h2 class="sc-titulo"><?php the_title(); ?></h2>
				<p class="sc-sinopse"><b>Sinopse: </b><?php echo strip_tags(substr(get_the_content(''), 0, 160).' [..]'); ?></p>
				<div class="sc-compartilhe">
					<div class="img">
						<img src="<?php echo get_post_meta($post->ID, 'imagem', true); ?>" alt="<?php the_title(); ?>" title="<?php the_title(); ?>" />
					</div>

					<div class="sc-compartilhar">
						<p><b>Gostou? Compartilhe:</b></p>
						<ul class="sc-botoesComp">
							<li>
								<a href="https://twitter.com/share" class="twitter-share-button" data-lang="en">Tweet</a>
								<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="https://platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>
							</li>

							<li>
								<script>(function(d, s, id) {
								var js, fjs = d.getElementsByTagName(s)[0];
								if (d.getElementById(id)) return;
								js = d.createElement(s); js.id = id;
								js.src = "//connect.facebook.net/pt_BR/all.js#xfbml=1&appId=131875680297573";
								fjs.parentNode.insertBefore(js, fjs);
								}(document, 'script', 'facebook-jssdk'));</script>
								<div class="fb-like" data-href="<?php the_permalink(); ?>" data-send="false" data-layout="button_count" data-width="90" data-show-faces="false"></div>
							</li>

							<li>
								<div class="g-plusone" data-size="medium"></div>
								<script type="text/javascript">
								window.___gcfg = {lang: 'pt-BR'};
								(function() {
								var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
								po.src = 'https://apis.google.com/js/plusone.js';
								var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
								})();
								</script>
							</li>
						</ul>

						<div class="sc-avalicao"><b>Avaliação pública:</b><?php if(function_exists('the_ratings')){the_ratings();} ?></div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php endwhile; wp_reset_query();
	} ?>

	<div class="topo">
		<div class="center">
			<a href="<?php bloginfo('url'); ?>" title="<?php bloginfo('name'); ?>" class="logo"><?php bloginfo( 'name'); ?></a>

			<ul class="menu">
				<?php
					$args = array(
						'container'       => '',
						'fallback_cb'     => '',
						'echo'            => true,
						'link_before'     => '',
						'link_after'      => '',
						'items_wrap'      => '%3$s',
						'theme_location'  => 'topo_menu'
					);

					wp_nav_menu($args);
				?>
			</ul>

			<form action="<?php echo get_settings('home'); ?>" method="get" class="pesquisa">
				<input type="text" value="Pesquise filmes e séries." name="s" class="campo" onclick="javascript:value=''" />
				<input type="submit" class="btn" name="s-btn" value="Pesquisar" />
			</form>
		</div>
	</div>
</div>